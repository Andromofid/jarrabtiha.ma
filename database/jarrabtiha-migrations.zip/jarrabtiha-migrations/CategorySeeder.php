<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'العناية بالشعر', 'icon' => '💇‍♀️', 'order' => 1],
            ['name' => 'العناية بالبشرة', 'icon' => '✨',   'order' => 2],
            ['name' => 'الميكياج',        'icon' => '💄',   'order' => 3],
            ['name' => 'العطور',          'icon' => '🌸',   'order' => 4],
            ['name' => 'العناية بالجسم',  'icon' => '🧴',   'order' => 5],
            ['name' => 'الأظافر',         'icon' => '💅',   'order' => 6],
        ];

        foreach ($categories as $cat) {
            DB::table('categories')->insert([
                'name'       => $cat['name'],
                'slug'       => Str::slug($cat['name']),
                'icon'       => $cat['icon'],
                'order'      => $cat['order'],
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
