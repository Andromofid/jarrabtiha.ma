<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            CategorySeeder::class,  // 1. Parents + sous-catégories
            ProductSeeder::class,   // 2. Produits (dépend des catégories)
        ]);
    }
}
